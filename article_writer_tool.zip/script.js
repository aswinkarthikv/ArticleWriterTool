document.getElementById('submit').addEventListener('click', async () => {
    let title = document.getElementById('title').value;
    if (!title) return alert('Enter a title!');

    let response = await fetch('/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ title })
    });

    let data = await response.json();
    animateText(data.article);
});

document.getElementById('optimize').addEventListener('click', async () => {
    let existingContent = document.getElementById('editor').innerText;

    let response = await fetch('/optimize', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ content: existingContent })
    });

    let data = await response.json();
    animateOptimization(data.optimizedArticle);
});

function animateText(text) {
    let editor = document.getElementById('editor');
    editor.innerHTML = "";
    
    let i = 0;
    function typingEffect() {
        if (i < text.length) {
            editor.innerHTML += text[i];
            i++;
            setTimeout(typingEffect, 50);
        }
    }
    typingEffect();
}

function animateOptimization(newText) {
    let editor = document.getElementById('editor');
    let oldText = editor.innerText;

    editor.innerHTML = "";  
    let i = 0;
    function eraseEffect() {
        if (i < oldText.length) {
            editor.innerText = oldText.slice(0, oldText.length - i);
            i++;
            setTimeout(eraseEffect, 30);
        } else {
            pencilEffect();
        }
    }

    function pencilEffect() {
        let j = 0;
        function writeNew() {
            if (j < newText.length) {
                editor.innerHTML += newText[j];
                j++;
                setTimeout(writeNew, 50);
            }
        }
        writeNew();
    }

    eraseEffect();
}