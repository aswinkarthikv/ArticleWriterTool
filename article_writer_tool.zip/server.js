const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const fetch = require('node-fetch');

const app = express();
app.use(cors());
app.use(bodyParser.json());

const GOOGLE_AI_API_KEY = 'YOUR_GOOGLE_AI_KEY'; // Replace with your API Key

async function generateArticle(title) {
    const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/text-bison-001:generateText?key=${GOOGLE_AI_API_KEY}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            prompt: { text: `Write a detailed article on "${title}".` },
            temperature: 0.7,
        })
    });

    const data = await response.json();
    return data.candidates[0].output || "Failed to generate article.";
}

async function optimizeArticle(content) {
    const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/text-bison-001:generateText?key=${GOOGLE_AI_API_KEY}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            prompt: { text: `Optimize and improve the following article:

${content}` },
            temperature: 0.5,
        })
    });

    const data = await response.json();
    return data.candidates[0].output || "Failed to optimize article.";
}

app.post('/generate', async (req, res) => {
    const { title } = req.body;
    const article = await generateArticle(title);
    res.json({ article });
});

app.post('/optimize', async (req, res) => {
    const { content } = req.body;
    const optimizedArticle = await optimizeArticle(content);
    res.json({ optimizedArticle });
});

app.listen(3000, () => console.log('Server running on port 3000'));